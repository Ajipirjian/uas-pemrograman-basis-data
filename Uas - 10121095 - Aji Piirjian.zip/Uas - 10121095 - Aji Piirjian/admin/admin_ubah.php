<?php
session_start();
error_reporting(0);
include 'koneksi.php';

// Ambil ID karyawan yang akan diubah
$id_karyawan_to_update = $_GET['id_karyawan'];

// Query untuk mengambil data karyawan berdasarkan ID
$sql_select = "SELECT * FROM tb_karyawan WHERE id_karyawan = '$id_karyawan_to_update'";
$result = mysqli_query($koneksi, $sql_select);

// Periksa apakah data ditemukan
if(mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result); // Ambil data sebagai asosiatif array
    $id_karyawan = $row['id_karyawan'];
    $username = $row['username'];
    // Baca data lainnya dari $row sesuai kebutuhan
} else {
    echo "Data karyawan tidak ditemukan.";
}

// Proses input
if (isset($_POST['ubahdata'])) {
    $new_username = $_POST['new_username'];
    $new_password = md5($_POST['new_password']); // Gunakan md5() untuk mengenkripsi password

    // Proses ubah data ke Database
    $sql = "UPDATE tb_karyawan SET username='$new_username', password='$new_password' WHERE id_karyawan='$id_karyawan'";
    $ubah = mysqli_query($koneksi, $sql);

    if ($ubah) {
        echo "<script>alert('Ubah Username dan Password Dengan ID Karyawan = " . $id_karyawan . " Berhasil') </script>";
        echo "<script>window.location.href = \"datakaryawan.php\" </script>";
    } else {
        echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Form Ubah Data Karyawan</title>
</head>
<body>
    <h2>Form Ubah Data Karyawan</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="id_karyawan" value="<?php echo $id_karyawan; ?>">
        <label for="new_username">Username Baru:</label><br>
        <input type="text" id="new_username" name="new_username" value="<?php echo $username; ?>"><br><br>
        <label for="new_password">Password Baru:</label><br>
        <input type="password" id="new_password" name="new_password"><br><br>
        <input type="submit" name="ubahdata" value="Ubah Data">
    </form>
</body>
</html>
